#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "timer.h"
#include "stm32_dsp.h"
#include "lcd.h"
#include "adc.h"
#include "key.h"

/*   AD�������ţ�PC1      */
/*   ����Ƶ��  ��2000Hz   */
/*   ����3.0VPP  ֱ��ƫ����1.5V */
float Voltage_Target	=2.77;								

#define Voltage_Kp	(0.15)									// ��ѹ������ϵ��
#define Voltage_Ki	(0.0085f)									// ��ѹ������ϵ��
#define Voltage_Kd	(0.00005f)									// ��ѹ��΢��ϵ��	
#define Current_Kp	(0.0015)									// ��ѹ������ϵ��
#define Current_Ki	(0.004f)									// ��ѹ������ϵ��
#define Definite_Integral_Threshold (800)				// ��ѹ�����ֽ׶���ֵ
#define Definite_Integral_Modulation_Max (0.6f)	// ���ƶȶ����ֽ׶���ֵt

#define Modulation_Max1 (0.9f)										// ���ƶ����ֵ
#define Modulation_Min1 (0.0f)										// ���ƶ���Сֵ
#define Modulation_Max2 (0.9f)										// ���ƶ����ֵ
#define Modulation_Min2 (0.0f)										// ���ƶ���Сֵ
/*   AD�������ţ�PC1      */
/*   ����Ƶ��  ��2000Hz   */
/*   ����3.0VPP  ֱ��ƫ����1.5V */

float Modulation1=0.2;
float Modulation2=0.05;
uint8_t PID_flag=0;//Cache_Select=0;
float uo,ib,u1,i1,io,uo1,ib1,u11,i11,io1;
float po,pi,pb=0;
u16 count=0;
u16 flag,flag1=0;
u16 flag2=0;
 u16 a=0,b=0;
void data_handle()
{
	uo=(float)ADC_Value[0]*3.3/4096;
	ib=(float)ADC_Value[1]*3.3/4096;
	u1=(float)ADC_Value[2]*3.3/4096;
	i1=(float)ADC_Value[3]*3.3/4096;
	io=(float)ADC_Value[4]*3.3/4096;
	uo1=((float)ADC_Value[0]*3.3/4096-0.2763)/0.0859;
	ib1=((float)ADC_Value[1]*3.3/4096-1.6892)/(-0.7383);
	u11=((float)ADC_Value[2]*3.3/4096)*25;
	i11=(((float)ADC_Value[3]*3.3/4096)-2.4912)/0.1731;
	io1=((float)ADC_Value[4]*3.3/4096+0.0358)/0.6857;
		
	po=uo1*uo1/(float)(25);
	pi=((u11+10*i11)/2)*((u11+10*i11)/2)/10;
}
void change_flag()
{
	data_handle();
	
	if(po<pi||flag1==0) flag2= 0;
	else flag2=1;//1 ��翪�Ϲ� 0�ŵ�
	
}
//�ȿ��������ѹΪ30V
float Voltage_PID(float Voltage_Result)//ADC_Value[0]
{
		static float Voltage_Error[3]={0,0,0},
					Voltage_PID_Error[3]={0,0,0};
		//static float Modulation1=0.5f;	
					
		Voltage_Error[2]=Voltage_Error[1];//���ϴ�ƫ��
		Voltage_Error[1]=Voltage_Error[0];//�ϴ�ƫ��
		Voltage_Error[0]=Voltage_Target-Voltage_Result;//��ǰƫ��ֵ
		Voltage_PID_Error[0]=Voltage_Error[0]-Voltage_Error[1];//����ƫ��-�ϴ�ƫ��EK-EK-1
		Voltage_PID_Error[1]=Voltage_Error[0];//�������;EK
		Voltage_PID_Error[2]=Voltage_Error[0] 
								- 2*Voltage_Error[1] + Voltage_Error[2];
			if(flag==1)
		{																										
			Modulation1 += (float)(Voltage_Kp*(float)Voltage_PID_Error[0]
					+Voltage_Ki*(float)Voltage_PID_Error[1]);
		}
					//+Voltage_Kd*(float)Voltage_PID_Error[2]);

		//���ƶ��޷�					
		if(Modulation1>Modulation_Max1)	Modulation1=Modulation_Max1;	//���1
		if(Modulation1<Modulation_Min1)	Modulation1=Modulation_Min1;//��С0.2
//ռ�ձ�0-1
		return Modulation1;
					
}

float Current_PID(float Current_Result)//һ�Ի�����PWM
{
		float Ib_Target;
		
		static float Current_Error[3]={0,0,0},
					Current_PID_Error[3]={0,0,0};
//		static float Modulation2=0.5f;	
		po=uo*uo/(float)25;
	    pi=(u1+10*i1)*(u1+10*i1)/4;
		Ib_Target =(po-pi)/15;
					
		Current_Error[2]=Current_Error[1];//���ϴ�ƫ��
		Current_Error[1]=Current_Error[0];//�ϴ�ƫ��
		Current_Error[0]=Ib_Target-Current_Result;//��ǰƫ��ֵ
		Current_PID_Error[0]=Current_Error[0]-Current_Error[1];//����ƫ��-�ϴ�ƫ��EK-EK-1
		Current_PID_Error[1]=Current_Error[0];//�������;EK
		Current_PID_Error[2]=Current_Error[0] 
								- 2*Current_Error[1] +Current_Error[2];
		if(count==1000&&flag1==1)//==1&&flag2==0){	//count�ϻ�																									
		{Modulation2+= (Current_Kp*(float)Current_PID_Error[0]
					+Current_Ki*(float)Current_PID_Error[1]);
		}
//		if(count==1000&&flag1==1&&flag2==1){	//count�ϻ�																									
//			Modulation2+= (Current_Kp*(float)Current_PID_Error[0]
//					+Current_Ki*(float)Current_PID_Error[1]);
//		}
					//+Voltage_Kd*(float)Voltage_PID_Error[2]);

		//���ƶ��޷�					
		if(Modulation2>Modulation_Max2)	Modulation2=Modulation_Max2;	//���1
		if(Modulation2<Modulation_Min2)	Modulation2=Modulation_Min2;//��С0.2

		return Modulation2;
					
}


void show()
{
	POINT_COLOR=RED;	//������ɫ
	LCD_ShowString(0,16,100,16,16,"U0:");
	LCD_ShowFloat4(24,16,uo,4,16);
	LCD_ShowString(62+40,16,100,16,16,"V");
	
	LCD_ShowString(0,16*2,100,16,16,"IB:");
	LCD_ShowFloat4(24,16*2,ib,4,16);
	LCD_ShowString(62+40,16*2,100,16,16,"A");
	
	LCD_ShowString(0,16*3,100,16,16,"U1:");
	LCD_ShowFloat4(24,16*3,u1,4,16);
	LCD_ShowString(62+40,16*3,100,16,16,"V");
	
	LCD_ShowString(0,16*4,100,16,16,"I1:");
	LCD_ShowFloat4(24,16*4,i1,4,16);
	LCD_ShowString(62+40,16*4,100,16,16,"V");
	if(flag==0)
	LCD_ShowString(0,16*5,100,16,16,"1N");
	else LCD_ShowString(0,16*5,100,16,16,"1Y");
	if(flag1==1&&count==1000)
	LCD_ShowString(0,16*6,100,16,16,"2Y");
	else LCD_ShowString(0,16*6,100,16,16,"2N");
	LCD_ShowString(0,16*7,100,16,16,"m1:");
	LCD_ShowFloat4(16*4,16*7,Modulation1,4,16);
	LCD_ShowString(0,16*8,100,16,16,"m2:");
	LCD_ShowFloat4(16*4,16*8,Modulation2,4,16);
//	LCD_ShowString(0,16*9,100,16,16,"cou:");
//	 LCD_ShowxNum(16*5,16*9,count,4,16,0);
	if(flag2==0) LCD_ShowString(0,16*9,100,16,16,"chong 1 PA08");
	else LCD_ShowString(0,16*9,100,16,16,"fang  0 PA10");
	LCD_ShowString(0,16*10,100,16,16,"PI:");
	LCD_ShowFloat4(24,16*10,pi,4,16);
	LCD_ShowString(0,16*11,100,16,16,"PO:");
	LCD_ShowFloat4(24,16*11,po,4,16);
	LCD_ShowString(0,16*12,100,16,16,"IO:");
	LCD_ShowFloat4(24,16*12,po,4,16);
		
	
	
}	





int main(void)
 {
	int i;
	 u16 v_valid=0;
	 float temp=0.0,v_now=0.0;
	 u16 adcx=0;
	 u8 key=0;
	 PID_flag=0;
	 KEY_Init(); 

  delay_init();	    	 //��ʱ������ʼ��	  
	uart_init(115200);	
  LCD_Init();
	TIM1_PWM_Init();//10kPWM
	 TIM8_PWM_Init();//10kPWM
	 TIM4_PWM_Init();
	  TIM2_Int_Init(99,72-1);//10K
	//TIM1_Int_Init(1000-1,30-1);//2400Hz�Ĳ���Ƶ��
	 //TIM1_Int_Init(74,4);    //192KHz����Ƶ�ʣ�72MHz/5=14.4MHz,������75����ʱΪ5/72M*75=1/192K��
	 //TIM1_Int_Init(75-1,150-1);    //9.6kHz����Ƶ�ʣ�72MHz/5=14.4MHz,������150����ʱΪ5/72M*75=1/9.6K��
	ADC1_Configuration();   //ADC��ʼ��
	DMA_Configuration();    //DMA��ʼ��
	//InitBufInArray2();//�����õ�
	 LCD_Clear(WHITE);

	while(1)
	{
		data_handle();
		
		key=KEY_Scan(0);	//�õ���ֵ
	   	if(key)
		{						   
			switch(key)
			{				 
				case WKUP_PRES:	//���Ʒ�����
					//BEEP=!BEEP;
				if(a==0){flag=1;a=1;}
				else if(a==1){flag=0;a=0;};
				
					break; 
				case KEY1_PRES:	//����LED1��ת	 
					
				//flag=0;
					Modulation1=	Modulation1+0.01;
					Modulation2=	Modulation2+0.01;
				
				if(Modulation1>Modulation_Max1)	Modulation1=Modulation_Max1;	//���1
				if(Modulation2>Modulation_Max2)	Modulation2=Modulation_Max2;	//���1
					break;
				case KEY0_PRES:	//ͬʱ����LED0,LED1��ת 
					//Voltage_Target=Voltage_Target+0.1;
//				if(b==0){flag1=1;b=1;}
//				else if(b==1){flag1=0;b=0;};
				 Voltage_Target= Voltage_Target-0.01;
				
					
					break;
			}
		}else delay_ms(10);
		Modulation1=Voltage_PID(uo);//;
		if(times==10&&flag1==1) {change_flag();Modulation2=Current_PID(ib);times=0;}
		show();
		
		
	}	 
}





