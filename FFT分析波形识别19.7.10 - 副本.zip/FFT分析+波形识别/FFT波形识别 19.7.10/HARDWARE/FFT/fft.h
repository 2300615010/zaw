#ifndef __FFT_H
#define __FFT_H
#include "sys.h"

#define   NPT   1024

extern u32 lBufInArray[NPT];

extern u32 lBufInArray1[NPT];
extern u32 lBufInArray2[NPT];
extern u32 lBufOutArray[NPT];
extern u32 lBufOutArray1[NPT];
extern u32 lBufOutArray2[NPT];
extern u32 lBufMagArray[NPT];
extern u32 lBufMagArray1[NPT];
extern u32 lBufMagArray2[NPT];
extern u32 lBUFPHASE[NPT];
void GetPowerMag(u32 *a,u32 *b);
void PowerPhase(u32 *a,u32 *b);
void InitBufInArray(void);
void InitBufInArray2(void);
void lcd_print_fft(unsigned int *p,u16 s);
void lcd_show_fft(unsigned int *p);
void select_max(float *f,float *a,u16 s);

void window();
#endif
