/*
 * Nongli.h
 *
 *  Created on: Jan 13, 2020
 *      Author: Ambassador
 */

#ifndef INC_NONGLI_H_
#define INC_NONGLI_H_

typedef struct
{
	int year;
	int month;
	int day;
	int reserved;
} hjz;

extern void Gregorian2Lunar_Display(char x, char y, int gyear, int gmonth, int gday);

#endif /* INC_NONGLI_H_ */
