#include "My_OLED.h"
#include "../OLED/OLED.h"
#include <string.h>
#include "Lunar.h"

extern RTC_HandleTypeDef hrtc;
RTC_DateTypeDef GetData;  //��ȡ���ڽṹ��
RTC_TimeTypeDef GetTime;   //��ȡʱ��ṹ��

const unsigned char Hzk[][32] =
{
{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xE0, 0xF0, 0xB0, 0x90, 0x90, 0x10, 0xF0,
		0xF0, 0x00, 0x00 },
{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x07, 0x04, 0x04, 0x04, 0x08, 0x1F,
		0x0F, 0x00, 0x00 },/*"��",0*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0xC0, 0xC0, 0xC0, 0xC0,
		0xC0, 0xC0, 0x80 },
{ 0x00, 0x00, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x01 },/*"һ",1*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x70, 0x30, 0x30, 0x30, 0x30, 0x30, 0x10,
		0x00, 0x00, 0x00 },
{ 0x00, 0x00, 0x00, 0x04, 0x06, 0x06, 0x06, 0x06, 0x02, 0x02, 0x02, 0x03, 0x03,
		0x03, 0x03, 0x06 },/*"��",2*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0xB0, 0xB0, 0xB0, 0x90, 0x00,
		0x00, 0x00, 0x00 },
{ 0x00, 0x00, 0x00, 0x08, 0x08, 0x08, 0x08, 0x05, 0x05, 0x04, 0x04, 0x04, 0x04,
		0x04, 0x04, 0x04 },/*"��",3*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0xE0, 0xE0, 0x20, 0xA0, 0xF0, 0x30, 0x30, 0xF0, 0x90, 0x10,
		0x10, 0xF0, 0xF0 },
{ 0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x06, 0x04,
		0x06, 0x03, 0x00 },/*"��",4*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x98, 0x98, 0xD8, 0x78, 0x58, 0xCC, 0xCC,
		0x00, 0x00, 0x00 },
{ 0x00, 0x00, 0x00, 0x08, 0x08, 0x08, 0x0C, 0x0F, 0x0D, 0x0C, 0x06, 0x07, 0x05,
		0x0C, 0x0C, 0x0C },/*"��",5*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x80, 0x80, 0x80, 0x80, 0x80, 0xC0, 0xC0, 0xCC, 0x58, 0x40, 0x60, 0x60,
		0x60, 0x60, 0x60 },
{ 0x00, 0x00, 0x01, 0x00, 0x08, 0x0C, 0x07, 0x02, 0x00, 0x00, 0x00, 0x02, 0x06,
		0x0E, 0x0C, 0x00 },/*"��",6*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0xFC, 0xEC, 0x40, 0x40, 0x40,
		0x60, 0x60, 0x60 },
{ 0x00, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01, 0x07, 0x0C, 0x0C, 0x0C,
		0x0C, 0x00, 0x00 },/*"��",7*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0xC0, 0x00, 0x18, 0x30, 0x40, 0x80, 0x00,
		0x00, 0x00, 0x00 },
{ 0x00, 0x00, 0x04, 0x06, 0x03, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03,
		0x07, 0x06, 0x06 },/*"��",8*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x80, 0x80, 0x80, 0xC0, 0xF8, 0x38, 0xE0, 0xE0, 0x00,
		0x00, 0x00, 0x00 },
{ 0x00, 0x00, 0x00, 0x11, 0x09, 0x08, 0x06, 0x01, 0x00, 0x00, 0x0F, 0x10, 0x10,
		0x10, 0x10, 0x10 },/*"��",9*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x80, 0x40, 0xF8, 0xF8, 0x48, 0x40,
		0x40, 0x40, 0x40 },
{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0F, 0x0F, 0x00, 0x00,
		0x00, 0x00, 0x00 },/*"ʮ",10*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x98, 0x78, 0x5C, 0xCC, 0xEC, 0x44, 0x7C,
		0x18, 0x00, 0x00 },
{ 0x00, 0x00, 0x00, 0x00, 0x24, 0x12, 0x11, 0x15, 0x15, 0x1F, 0x1F, 0x15, 0x13,
		0x10, 0x10, 0x10 },/*"��",11*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x10, 0xFC, 0x34, 0x08, 0xFE, 0x0A, 0x00, 0xF8, 0xA8,
		0x08, 0xF8, 0x00 },
{ 0x00, 0x02, 0x02, 0x0A, 0x0E, 0x01, 0x01, 0x03, 0x15, 0x09, 0x07, 0x01, 0x10,
		0x10, 0x1F, 0x00 },/*"��",12*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0xC0, 0x40, 0xC0, 0xE6, 0xE4, 0x80, 0x40, 0x40, 0x60, 0xA0,
		0x20, 0x20, 0xE0 },
{ 0x00, 0x00, 0x00, 0x04, 0x06, 0x03, 0x1F, 0x11, 0x08, 0x08, 0x06, 0x03, 0x10,
		0x10, 0x3C, 0x0F },/*"��",13*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0xF0, 0xF0, 0x80, 0x80, 0x80, 0xF8, 0xF0,
		0x80, 0x80, 0x80 },
{ 0x00, 0x00, 0x01, 0x01, 0x01, 0x01, 0x07, 0x1F, 0x18, 0x18, 0x1E, 0x1F, 0x00,
		0x00, 0x00, 0x01 },/*"إ",14*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x98, 0x18, 0xF8, 0xF8, 0xC8, 0x48, 0x00,
		0x00, 0x00, 0x00 },
{ 0x00, 0x00, 0x08, 0x08, 0x08, 0x04, 0x07, 0x04, 0x07, 0x07, 0x04, 0x04, 0x04,
		0x04, 0x04, 0x0C },/*"��",15*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x80, 0xFC, 0xD4, 0xFC, 0x84, 0xB0, 0x7E, 0xD0, 0xF0,
		0xFE, 0xDB, 0x48 },
{ 0x00, 0x00, 0x08, 0x06, 0x03, 0x08, 0x08, 0x1F, 0x00, 0x00, 0x0F, 0x0A, 0x0A,
		0x11, 0x1F, 0x00 },/*"��",16*/
/* (16 X 16 , ������κ )*/

{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0xA8, 0xA4, 0x04, 0xFC, 0xFC,
		0x00, 0x00, 0x00 },
{ 0x00, 0x00, 0x00, 0x10, 0x08, 0x0C, 0x03, 0x01, 0x08, 0x08, 0x10, 0x1F, 0x1F,
		0x00, 0x00, 0x00 }, /*"��",17*/
/* (16 X 16 , ������κ )*/
};

const unsigned char F4X6[][4] =
{
{ 0x00, 0x1F, 0x11, 0x1F },/*0*/
{ 0x00, 0x00, 0x00, 0x1F },/*1*/
{ 0x00, 0x1D, 0x15, 0x17 },/*2*/
{ 0x00, 0x15, 0x15, 0x1F },/*3*/
{ 0x00, 0x07, 0x04, 0x1F },/*4*/
{ 0x00, 0x17, 0x15, 0x1D },/*5*/
{ 0x00, 0x1F, 0x15, 0x1D },/*6*/
{ 0x00, 0x01, 0x01, 0x1F },/*7*/
{ 0x00, 0x1F, 0x15, 0x1F },/*8*/
{ 0x00, 0x17, 0x15, 0x1F }, /*9*/
};

void OLED_Showsmallnum(unsigned char x, unsigned char y, unsigned char chr)
{
	unsigned char i = 0;
	x *= 4;
	OLED_Set_Pos(x, y);
	for (i = 0; i < 4; i++)
		OLED_WR_Byte(F4X6[chr][i], OLED_DATA);
}

char* itoa(int num, char *str, int radix)
{/*������*/
	char index[] = "0123456789ABCDEF";
	unsigned unum;/*�м����*/
	int i = 0, j, k;
	/*ȷ��unum��ֵ*/
	if (radix == 10 && num < 0)/*ʮ���Ƹ���*/
	{
		unum = (unsigned) -num;
		str[i++] = '-';
	}
	else
		unum = (unsigned) num;/*�������*/
	/*ת��*/
	do
	{
		str[i++] = index[unum % (unsigned) radix];
		unum /= radix;
	} while (unum);
	str[i] = '\0';
	/*����*/
	if (str[0] == '-')
		k = 1;/*ʮ���Ƹ���*/
	else
		k = 0;

	for (j = k; j <= (i - 1) / 2; j++)
	{
		char temp;
		temp = str[j];
		str[j] = str[i - 1 + k - j];
		str[i - 1 + k - j] = temp;
	}
	return str;
}

void Date_Display(void)
{
	static char strs[11], strt[11];
	strs[0] = '\0';
	itoa(2000 + GetData.Year, strt, 10);
	strcat(strt, "-");
	strcat(strs, strt);
	itoa(GetData.Month, strt, 10);
	if (GetData.Month <= 9)
		strcat(strs, "0");
	strcat(strt, "-");
	strcat(strs, strt);
	itoa(GetData.Date, strt, 10);
	if (GetData.Date <= 9)
		strcat(strs, "0");
	strcat(strs, strt);
	OLED_ShowString(64 - 4 * strlen(strs), 0, strs, 8);
	OLED_ShowCHinese(32, 4, GetData.WeekDay);
	Gregorian2Lunar_Display(64 - 16, 4, 2000 + GetData.Year, GetData.Month, GetData.Date);
}

void OLED_Refresh(void)
{
	OLED_ShowNum(26, 2, GetTime.Hours % 10, 1, 16);
	OLED_ShowNum(16, 2, GetTime.Hours / 10, 1, 16);

	OLED_ShowNum(66, 2, GetTime.Minutes % 10, 1, 16);
	OLED_ShowNum(56, 2, GetTime.Minutes / 10, 1, 16);

	OLED_ShowNum(106, 2, GetTime.Seconds % 10, 1, 16);
	OLED_ShowNum(96, 2, GetTime.Seconds / 10, 1, 16);

	Date_Display();
}

void OLED_Display_Init(void)
{
	OLED_ShowChar(40, 2, ':', 16);
	OLED_ShowChar(80, 2, ':', 16);

	RTC_Read();
	OLED_Refresh();

	OLED_ShowCHinese(0, 4, 11);		//��
	OLED_ShowCHinese(16, 4, 12);	//��
	OLED_ShowCHinese(80, 4, 17);	//��

	OLED_ShowString(64 - 4 * strlen("    <Home>    "), 6, "    <Home>    ", 16);
}

void RTC_Read(void)
{
	HAL_RTC_GetTime(&hrtc, &GetTime, RTC_FORMAT_BIN);
	HAL_RTC_GetDate(&hrtc, &GetData, RTC_FORMAT_BIN);
}

static uint8_t Mid_Key_Flag = 0;

#include "Perpetual_Calendar.h"
void HAL_RTCEx_RTCEventCallback(RTC_HandleTypeDef *hrtc)
{
  static uint8_t MH_Flag = 0;

  if(Mid_Key_Flag == 7)
	  return;

//  HAL_RTC_GetTime(hrtc, &GetTime, RTC_FORMAT_BIN);
//  HAL_RTC_GetDate(hrtc, &GetData, RTC_FORMAT_BIN);

  OLED_Refresh();

  if(MH_Flag)
  {
  	MH_Flag = 0;
  	OLED_ShowChar(40, 2, ':', 16);
  	OLED_ShowChar(80, 2, ':', 16);
  }
  else
  {
  	MH_Flag = 1;
  	OLED_ShowChar(40, 2, ' ', 16);
  	OLED_ShowChar(80, 2, ' ', 16);
  }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	RTC_TimeTypeDef sTime = {0};
	RTC_DateTypeDef DateToUpdate = {0};
	switch(GPIO_Pin)
	{
	case Right_Key_Pin:
		RTC_Read();
		switch(Mid_Key_Flag)
		{
			case 1:
				GetTime.Seconds ++;
				break;
			case 2:
				GetTime.Minutes ++;
				break;
			case 3:
				GetTime.Hours ++;
				break;
			case 4:
				GetData.Date ++;
				break;
			case 5:
				GetData.Month ++;
				break;
			case 6:
				GetData.Year ++;
				break;
			default:
				return;
		}
		if(GetTime.Seconds == 60)
		{
			GetTime.Seconds = 0;
			GetTime.Minutes ++;
		}
		if(GetTime.Minutes == 60)
		{
			GetTime.Minutes = 0;
			GetTime.Hours ++;
		}
		if(GetTime.Hours == 24)
		{
			GetTime.Hours = 0;
			GetData.Date ++;
		}
		if(GetData.Date > days_of_month(GetData.Year + 2000, GetData.Month))
		{
			GetData.Date = 1;
			GetData.Month ++;
		}
		if(GetData.Month > 12)
		{
			GetData.Month = 1;
			GetData.Year ++;
		}
		if(GetData.Year > 99)
		{
			GetData.Year = 99;
		}

		sTime.Hours = GetTime.Hours;
		sTime.Minutes = GetTime.Minutes;
		sTime.Seconds = GetTime.Seconds;
		if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
		{
		  Error_Handler();
		}

		DateToUpdate.WeekDay = GetData.WeekDay;
		DateToUpdate.Month = GetData.Month;
		DateToUpdate.Date = GetData.Date;
		DateToUpdate.Year = GetData.Year;
		if (HAL_RTC_SetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BIN) != HAL_OK)
		{
		  Error_Handler();
		}

		RTC_Read();

		OLED_Refresh();
		break;
	case Mid_Key_Pin:
		Mid_Key_Flag ++;
		if(Mid_Key_Flag == 8)
			Mid_Key_Flag = 0;
		switch(Mid_Key_Flag)
		{
			case 0:
				OLED_Clear();
				OLED_Display_Init();
				break;
			case 1:
				OLED_ShowString(64 - 4 * strlen("<    >"), 6, "<    >", 16);
				OLED_ShowString(64 - 4 * strlen("Sec"), 6, "Sec", 16);
				break;
			case 2:
				OLED_ShowString(64 - 4 * strlen("<    >"), 6, "<    >", 16);
				OLED_ShowString(64 - 4 * strlen("Min"), 6, "Min", 16);
				break;
			case 3:
				OLED_ShowString(64 - 4 * strlen("<    >"), 6, "<    >", 16);
				OLED_ShowString(64 - 4 * strlen("Hour"), 6, "Hour", 16);
				break;
			case 4:
				OLED_ShowString(64 - 4 * strlen("<    >"), 6, "<    >", 16);
				OLED_ShowString(64 - 4 * strlen("Day"), 6, "Day", 16);
				break;
			case 5:
				OLED_ShowString(64 - 4 * strlen("<    >"), 6, "<    >", 16);
				OLED_ShowString(64 - 4 * strlen("Mon"), 6, "Mon", 16);
				break;
			case 6:
				OLED_ShowString(64 - 4 * strlen("<    >"), 6, "<    >", 16);
				OLED_ShowString(64 - 4 * strlen("Year"), 6, "Year", 16);
				break;
			case 7:
				OLED_Clear();
				HAL_RTC_GetDate(&hrtc, &GetData, RTC_FORMAT_BIN);
				print_date_of_month(GetData.Year + 2000, GetData.Month, GetData.Date, GetData.WeekDay);
				break;
			default:
				break;
		}
		break;
	case Left_Key_Pin:
		RTC_Read();
		switch(Mid_Key_Flag)
		{
			case 1:
				if(GetTime.Seconds != 0)
					GetTime.Seconds --;
				else
				{
					if(GetTime.Minutes != 0)
						GetTime.Minutes --;
					else
					{
						if(GetTime.Hours != 0)
							GetTime.Hours --;
						else
						{
							GetData.Date --;
							GetTime.Hours = 23;
						}
						GetTime.Minutes = 59;
					}
					GetTime.Seconds = 59;
				}
				break;
			case 2:
				if(GetTime.Minutes != 0)
					GetTime.Minutes --;
				else
				{
					if(GetTime.Hours != 0)
						GetTime.Hours --;
					else
					{
						GetData.Date --;
						GetTime.Hours = 23;
					}
					GetTime.Minutes = 59;
				}
				break;
			case 3:
				if(GetTime.Hours != 0)
					GetTime.Hours --;
				else
				{
					GetData.Date --;
					GetTime.Hours = 23;
				}
				break;
			case 4:
				GetData.Date --;
				break;
			case 5:
				GetData.Month --;
				break;
			case 6:
				if(GetData.Year != 0)
					GetData.Year --;
				break;
			default:
				return;
		}
		if(GetData.Date == 0)
		{
			if(GetData.Year == 0 && GetData.Month == 1)
				GetData.Date = 1;
			else
			{
				GetData.Month --;
				if(GetData.Month == 0)
				{
					if(GetData.Year != 0)
					{
						GetData.Month = 12;
						GetData.Year --;
					}
					else
					{
						GetData.Month = 1;
					}
				}
				GetData.Date = days_of_month(GetData.Year + 2000, GetData.Month);
			}
		}
		if(GetData.Month == 0)
		{
			if(GetData.Year != 0)
			{
				GetData.Month = 12;
				GetData.Year --;
			}
			else
			{
				GetData.Month = 1;
			}
		}

		sTime.Hours = GetTime.Hours;
		sTime.Minutes = GetTime.Minutes;
		sTime.Seconds = GetTime.Seconds;
		if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
		{
			Error_Handler();
		}

		DateToUpdate.WeekDay = GetData.WeekDay;
		DateToUpdate.Month = GetData.Month;
		DateToUpdate.Date = GetData.Date;
		DateToUpdate.Year = GetData.Year;
		if (HAL_RTC_SetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BIN) != HAL_OK)
		{
			Error_Handler();
		}

		RTC_Read();

		OLED_Refresh();
		break;
	}
}
