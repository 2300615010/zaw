#ifndef MY_OLED
#define MY_OLED

extern const unsigned char Hzk[][32];
extern const unsigned char F4X6[][4];

void OLED_Display_Init(void);
void OLED_Showsmallnum(unsigned char x, unsigned char y, unsigned char chr);
void OLED_Refresh(void);
void RTC_Read(void);

#endif
