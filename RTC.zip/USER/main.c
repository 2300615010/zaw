#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "timer.h"
#include "usart.h"	
#include "usmart.h"	 
#include "rtc.h" 
#include "oled.h"
 #include "beep.h"
 #include "exti.h"
 #include "oled2.h"
 
/************************************************
 ALIENTEK��ӢSTM32������ʵ��15
 RTCʵʱʱ��ʵ��  
 ����֧�֣�www.openedv.com
 �Ա����̣�http://eboard.taobao.com 
 ��ע΢�Ź���ƽ̨΢�źţ�"����ԭ��"����ѻ�ȡSTM32���ϡ�
 �������������ӿƼ����޹�˾  
 ���ߣ�����ԭ�� @ALIENTEK
************************************************/

//�ֲ������Ķ����������ڿ�ͷ
//����˼�룺����ǰʱ�����������������ͨ����������Ӧ�ı�������ʾ
 
 int main(void)
 {	 
 	u8 t=0;	
    u8 key=0;
	 u8 m=0;
	 u8 mon1_table[12]={0};
	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	 	//���ڳ�ʼ��Ϊ115200
 	LED_Init();			     //LED�˿ڳ�ʼ��
	//LCD_Init();	
	OLED_Init();
	OLED_Init1();
	 
	EXTIX_Init();
	TIM3_Int_Init(9999,7199);//72000000/7200=10000hz һ���ж�1S
	BEEP_Init();
	usmart_dev.init(SystemCoreClock/1000000);	//��ʼ��USMART	
	RTC_Init();	  			//RTC��ʼ��
	//POINT_COLOR=RED;//��������Ϊ��ɫ 
//	LCD_ShowString(60,50,200,16,16,"Elite STM32");	
//	LCD_ShowString(60,70,200,16,16,"RTC TEST");	
//	LCD_ShowString(60,90,200,16,16,"ATOM@ALIENTEK");
//	LCD_ShowString(60,110,200,16,16,"2020/5/17");		
	//��ʾʱ��
	//POINT_COLOR=BLUE;//��������Ϊ��ɫ
	OLED_ShowString(0,0,"    -  -  ",16);	   
	OLED_ShowString(0,40,"  :  :  ",16);	
	OLED_Refresh_Gram();
	OLED_ShowString1(0,10,"Please set",16);	
	OLED_ShowString1(0,32,"  ",16);
	OLED_Refresh_Gram1();
	RTC_Alarm_Set(2021,1,31,22,18,45)	;
	while(1)
	{								    
		if(t!=calendar.sec)
		{
			t=calendar.sec;
			OLED_ShowNum(0,0,calendar.w_year,4,16);									  
			OLED_ShowNum(40,0,calendar.w_month,2,16);									  
			OLED_ShowNum(64,0,calendar.w_date,2,16);
			
			switch(calendar.week)
			{
				case 0:
					OLED_ShowString(0,16,"Sunday   ",24);
					break;
				case 1:
					OLED_ShowString(0,16,"Monday   ",24);
					break;
				case 2:
					OLED_ShowString(0,16,"Tuesday  ",24);
					break;
				case 3:
					OLED_ShowString(0,16,"Wednesday",24);
					break;
				case 4:
					OLED_ShowString(0,16,"Thursday ",24);
					break;
				case 5:
					OLED_ShowString(0,16,"Friday   ",24);
					break;
				case 6:
					OLED_ShowString(0,16,"Saturday ",24);
					break;  
			}
			OLED_Refresh_Gram();
			OLED_ShowNum(0,40,calendar.hour,2,16);									  
			OLED_ShowNum(24,40,calendar.min,2,16);									  
			OLED_ShowNum(48,40,calendar.sec,2,16);
		
			
			//if(RTC_GetITStatus(RTC_IT_ALR)!= RESET){
			delay_ms(2000);//��˸
			OLED_ShowString(0,40,"  ",16);
			OLED_ShowString(24,40,"  ",16);
			OLED_ShowString(48,40,"  ",16);
			OLED_Refresh_Gram();
			delay_ms(2000);
			OLED_ShowNum(0,40,calendar.hour,2,16);									  
			OLED_ShowNum(24,40,calendar.min,2,16);									  
			OLED_ShowNum(48,40,calendar.sec,2,16);//}
			
		delay_ms(10);		
	key=KEY_Scan(0);
switch(key)
{
	case 1:
		calendar.w_year=calendar.w_year+1;
		if(calendar.w_year>2050) calendar.w_year=2020;
		RTC_Get();
		OLED_ShowNum(0,0,calendar.w_year,4,16);	
		OLED_Refresh_Gram();
		break;
	case 2:
		calendar.w_month=calendar.w_month+1;
	    if(calendar.w_month>12) calendar.w_month=1;
		RTC_Get();
		OLED_ShowNum(40,0,calendar.w_month,2,16);
		OLED_Refresh_Gram();
		break;
	case 3:
		calendar.w_date=calendar.w_date+1;
		 m=calendar.w_month;
		if(Is_Leap_Year(calendar.w_year))
		{
			mon1_table[1]=29;
			calendar.w_date=calendar.w_date+1;
			if(calendar.w_date>mon1_table[m]) calendar.w_date=1;
		}
		else
		{
			calendar.w_date=calendar.w_date+1;
			if(calendar.w_date>mon1_table[m]) calendar.w_date=1;
		}
		RTC_Get();
		OLED_ShowNum(64,0,calendar.w_date,2,16);
		OLED_Refresh_Gram();
		break;
	default:
		OLED_Refresh_Gram();
		
		


// }			
	};  
	}
	}
}
 
//	key=KEY_Scan(0);
//switch(key)
//{
//	case 1:
//		calendar.w_year=calendar.w_year+1;
//		if(calendar.w_year>2050) calendar.w_year=2020;
//		RTC_Get();
//		OLED_ShowNum(0,0,calendar.w_year,4,16);	
//		OLED_Refresh_Gram();
//		break;
//	case 2:
//		calendar.w_month=calendar.w_month+1;
//	    if(calendar.w_month>12) calendar.w_month=1;
//		RTC_Get();
//		OLED_ShowNum(40,0,calendar.w_month,2,16);
//		OLED_Refresh_Gram();
//		break;
//	case 3:
//		calendar.w_date=calendar.w_date+1;
//		 m=calendar.w_month;
//		if(Is_Leap_Year(calendar.w_year))
//		{
//			mon1_table[1]=29;
//			calendar.w_date=calendar.w_date+1;
//			if(calendar.w_date>mon1_table[m]) calendar.w_date=1;
//		}
//		else
//		{
//			calendar.w_date=calendar.w_date+1;
//			if(calendar.w_date>mon1_table[m]) calendar.w_date=1;
//		}
//		RTC_Get();
//		OLED_ShowNum(64,0,calendar.w_date,2,16);
//		OLED_Refresh_Gram();
//		break;
//	default:
//		OLED_Refresh_Gram();
//		
//		


// }

